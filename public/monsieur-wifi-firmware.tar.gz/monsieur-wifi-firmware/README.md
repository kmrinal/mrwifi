# monsieur-wifi-firmware

OpenWrt-based firmware for MrWiFi devices providing dual-band WiFi with captive portal functionality.

## Overview

This firmware enables WiFi devices to operate in dual-mode:
- **Password-protected WiFi** (`monsieur-wifi`) - Standard WPA2 network for authenticated users
- **Captive Portal WiFi** (`Mr WiFi Guest`) - Open network with captive portal authentication

## Key Features

### Network Configuration
- **Dual WiFi Networks**: Simultaneous password-protected and captive portal networks
- **Dynamic IP Management**: API-controlled IP address configuration for both networks
- **DHCP Management**: Configurable DHCP ranges and DNS settings
- **Network Isolation**: Separate network bridges for security

### Radio Management
- **Dual-band Support**: 2.4GHz and 5GHz radio configuration
- **Country Code Compliance**: Automatic regulatory domain configuration
- **Channel Management**: API-controlled channel and channel width settings
- **Power Control**: Configurable transmit power for both bands

### Captive Portal
- **Coova Chilli Integration**: Enterprise-grade captive portal solution
- **RADIUS Authentication**: Configurable RADIUS server integration
- **Domain Filtering**: Configurable blocked/allowed domains
- **Whitelist Management**: Server and domain whitelisting

### Remote Management
- **API Integration**: Automatic configuration updates from management API
- **Real-time Updates**: Dynamic configuration changes without manual intervention
- **Health Monitoring**: Automated heartbeat and status reporting

## Configuration Management

### Update Script (`/etc/citypassenger/update.sh`)

The main configuration management script that:
- Fetches configuration from the management API
- Applies network, wireless, and security settings
- Manages service restarts and configuration commits
- Ensures network interface reliability

#### Key Functions:
- **Bridge Configuration**: Automatic bridge interface management with IP assignment
- **Network Recovery**: Ensures interfaces are UP and properly configured after changes
- **DNS Management**: Dynamic DNS configuration based on domain filtering settings
- **Service Coordination**: Proper restart sequence for dependent services

### Network Interfaces

#### br-lan (Password WiFi Network)
- Default IP: `192.168.10.1/24`
- DHCP Range: `192.168.10.100-200`
- DNS: Configurable (8.8.8.8, 8.8.4.4 by default)
- Mode: Static or DHCP (API configurable)

#### br-network1 (Captive Portal Network)  
- Default IP: `192.168.2.1/24`
- DHCP Range: `192.168.2.100-200`
- DNS: Local IP when domain filtering active, otherwise configurable
- Integration: Coova Chilli for captive portal functionality

### Wireless Configuration

#### Radio0 (2.4GHz)
- **Channels**: 1-14 (country dependent)
- **Channel Width**: 20MHz, 40MHz
- **Power**: 0-30dBm (regulatory limited)
- **Mode**: HE20/HE40 (WiFi 6)

#### Radio1 (5GHz)
- **Channels**: 36-165 (country dependent)  
- **Channel Width**: 20MHz, 40MHz, 80MHz, 160MHz
- **Power**: 0-30dBm (regulatory limited)
- **Mode**: HE20/HE40/HE80/HE160 (WiFi 6)

## API Integration

### Settings Endpoint
```
GET /api/devices/{key}/{secret}/settings
```

#### Required Parameters:
- `key`: Device API key
- `secret`: Device secret
- `api_domain`: Management API domain

#### Configuration Fields:
- Network settings (IP, netmask, DNS, DHCP)
- Wireless settings (SSID, password, visibility, radio parameters)
- Security settings (country code, power limits)
- Captive portal settings (RADIUS, whitelisting, domain filtering)

### Automatic Updates
The device polls the API endpoint and applies configuration changes automatically:
- Network interface reconfiguration
- Wireless parameter updates
- Service restarts as needed
- Bridge interface recovery

## Installation & Setup

### Initial Configuration
1. Configure device API credentials in UCI:
   ```bash
   uci set citypassenger.@device[0].key="your_device_key"
   uci set citypassenger.@device[0].secret="your_device_secret"  
   uci set citypassenger.@device[0].api_domain="https://your-api-domain.com"
   uci commit citypassenger
   ```

2. Run initial update:
   ```bash
   /etc/citypassenger/update.sh
   ```

### Scheduled Updates
The update script can be scheduled via cron for automatic configuration synchronization:
```bash
# Update every 5 minutes
*/5 * * * * /etc/citypassenger/update.sh
```

## Troubleshooting

### Network Connectivity Issues
If network interfaces are not working after configuration changes:

1. **Check Interface Status**:
   ```bash
   ip addr show br-lan
   ip addr show br-network1
   ```

2. **Manual Interface Recovery**:
   ```bash
   ip link set br-lan up
   ip addr add 192.168.10.1/24 dev br-lan
   ```

3. **Run Bridge Configuration**:
   The update script includes automatic bridge recovery that runs after network changes.

### Service Management
```bash
# Restart network services
/etc/init.d/network restart

# Restart wireless
wifi reload

# Restart captive portal
/etc/init.d/chilli restart

# Restart DNS/DHCP
/etc/init.d/dnsmasq restart
```

### Log Monitoring
```bash
# System logs
logread

# Network interface logs
dmesg | grep -i network

# Chilli logs
logread | grep chilli
```

## Security Considerations

- **Network Isolation**: Password and captive portal networks are isolated
- **RADIUS Integration**: Enterprise authentication for captive portal
- **Domain Filtering**: Configurable content filtering and blocking
- **Regular Updates**: Automatic security configuration updates

## Support

For technical support and configuration assistance, refer to the MrWiFi management portal or contact the technical support team.

## Version Information

- **Base**: OpenWrt
- **Wireless Stack**: WiFi 6 (802.11ax) support
- **Captive Portal**: Coova Chilli
- **Management**: API-driven configuration
