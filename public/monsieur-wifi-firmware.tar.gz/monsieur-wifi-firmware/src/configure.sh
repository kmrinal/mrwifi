echo "Install script was executed"

# Write to logread message that script was executed
now=$(date)
echo "Install script was executed at $now" > /tmp/install.log
